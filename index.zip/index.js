$(document).ready(function(){
	for(var i =0; i < 10; i++){
		var tr = $('<tr>');
	
		var td = $('<td>');
		var rnaNumVar = getRandomInt(100);
		td.text(rnaNumVar);
		tr.append(td);
		
		var td2 = $('<td>');
		var rnaNumVar = getRandomInt(100);
		td2.text(rnaNumVar);
		tr.append(td2);
		
		var td2 = $('<td>');
		var rnaNumVar = getRandomInt(100);
		td2.text(rnaNumVar);
		tr.append(td2);
		
		var td2 = $('<td>');
		var rnaNumVar = getRandomInt(100);
		td2.text(rnaNumVar);
		tr.append(td2);
		
		var td2 = $('<td>');
		var rnaNumVar = getRandomInt(100);
		td2.text(rnaNumVar);
		tr.append(td2);

		
		$('table').append(tr);
	}
});

function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
function randElement(items){
	return items[Math.floor(Math.random() * items.length)];
}

